<a href="https://wa.me/+17863974240" class="whatsapp-btn" target="_blank">📱</a>
<footer>
    <p id="siguenos">Síguenos en nuestras redes sociales</p>
    <p><a href="https://www.facebook.com/share/18FPiTZjCY/?mibextid=wwXIfr">Facebook</a> | <a href="https://www.instagram.com/e20_miami?igsh=NzMxazl4ZjI5OWNm&utm_source=qr">Instagram</a> | <a href="https://wa.me/+17863974240" target="_blank">Whatsapp</a></p>
    <!--<p>Ubicación: Calle Falsa 123, Ciudad Jardín</p>-->
</footer>