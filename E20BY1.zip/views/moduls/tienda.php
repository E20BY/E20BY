<?php
$_SESSION['tienda'] = true;
$_SESSION['random'] = rand();
echo '<script>window.location="inicio"</script>';